/*
 * Main.cpp
 *
 *  Created on: May 8, 2020
 *      Author: ayushshrivastava
 */


#include <iostream>
#include <fstream>

#include "antlr4-runtime.h"
#include "CpasLexer.h"
#include "CpasParser.h"
#include "Pass1Visitor.h"
#include "Pass2Visitor.h"

using namespace std;
using namespace antlrcpp;
using namespace antlr4;

int main(int argc, const char *args[])
{
    ifstream ins;
    ins.open(args[1]);

    ANTLRInputStream input(ins);
    CpasLexer lexer(&input);
    CommonTokenStream tokens(&lexer);

    CpasParser parser(&tokens);
    tree::ParseTree *tree = parser.program();

    Pass1Visitor *pass1 = new Pass1Visitor();
    pass1->visit(tree);

    ostream& j_file = pass1->get_assembly_file();

    cout<<endl;
    cout<<endl;

    cout<<"*****************************Pass 2 Visit*******************************"<<endl;
    cout<<endl;

    Pass2Visitor *pass2 = new Pass2Visitor(j_file);
    pass2->visit(tree);

    //delete tree;
    return 0;
}

