#ifndef PASS1VISITOR_H_
#define PASS1VISITOR_H_

#include <iostream>

#include "wci/intermediate/SymTabStack.h"
#include "wci/intermediate/SymTabEntry.h"
#include "wci/intermediate/TypeSpec.h"

#include "CpasBaseVisitor.h"
#include "antlr4-runtime.h"
#include "CpasVisitor.h"

using namespace wci;
using namespace wci::intermediate;

class Pass1Visitor : public CpasBaseVisitor
{
private:
    SymTabStack *symtab_stack;
    SymTabEntry *program_id;
    vector<SymTabEntry *> variable_id_list;
    ofstream j_file;

public:
    Pass1Visitor();
    virtual ~Pass1Visitor();

    ostream& get_assembly_file();

    	antlrcpp::Any visitProgram(CpasParser::ProgramContext *ctx) override;
    	antlrcpp::Any visitBlock(CpasParser::BlockContext *ctx) override;
    	antlrcpp::Any visitDeclaration(CpasParser::DeclarationContext *ctx) override;
    	antlrcpp::Any visitDeclaration_stmt(CpasParser::Declaration_stmtContext *ctx) override;
    	antlrcpp::Any visitTypeID(CpasParser::TypeIDContext *ctx) override;
    	antlrcpp::Any visitVariableExpr(CpasParser::VariableExprContext *ctx) override;
    	antlrcpp::Any visitSignedNumber(CpasParser::SignedNumberContext *ctx) override;
        antlrcpp::Any visitUnsignedNumberExpr(CpasParser::UnsignedNumberExprContext *ctx) override;
        antlrcpp::Any visitCharConst(CpasParser::CharConstContext *ctx) override;
        antlrcpp::Any visitIntegerConst(CpasParser::IntegerConstContext *ctx) override;
        antlrcpp::Any visitFloatConst(CpasParser::FloatConstContext *ctx) override;
        antlrcpp::Any visitFunction_defn(CpasParser::Function_defnContext *ctx) override;
        antlrcpp::Any visitFuncID(CpasParser::FuncIDContext *ctx) override;


        antlrcpp::Any visitRelationOpExpr(CpasParser::RelationOpExprContext *ctx) override;
        antlrcpp::Any visitAddition_subtractionExpr(CpasParser::Addition_subtractionExprContext *ctx) override;
        antlrcpp::Any visitMultiply_divideExpr(CpasParser::Multiply_divideExprContext *ctx) override;
        antlrcpp::Any visitVarID(CpasParser::VarIDContext *ctx) override;
        antlrcpp::Any visitParenExpr(CpasParser::ParenExprContext *ctx) override;

        antlrcpp::Any visitFuctionCallExpr(CpasParser::FuctionCallExprContext *ctx) override;
};

#endif /* PASS1VISITOR_H_ */
