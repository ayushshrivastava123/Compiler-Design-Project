#ifndef PASS2VISITOR_H_
#define PASS2VISITOR_H_

#include <iostream>
#include <string>

#include "wci/intermediate/SymTabStack.h"
#include "wci/intermediate/SymTabEntry.h"
#include "wci/intermediate/TypeSpec.h"

#include "CpasBaseVisitor.h"
#include "antlr4-runtime.h"
#include "CpasVisitor.h"

using namespace wci;
using namespace wci::intermediate;

class Pass2Visitor : public CpasBaseVisitor
{
private:
	string program_name;
	ostream& j_file;

public:
	Pass2Visitor(ostream& j_file);
    virtual ~Pass2Visitor();

    	antlrcpp::Any visitStr(CpasParser::StrContext *ctx) override;
      	antlrcpp::Any visitLoop_while(CpasParser::Loop_whileContext *ctx) override;
        antlrcpp::Any visitIf_stmt(CpasParser::If_stmtContext *ctx) override;
        antlrcpp::Any visitProgram(CpasParser::ProgramContext *ctx) override;
        antlrcpp::Any visitVariableExpr(CpasParser::VariableExprContext *ctx) override;
        antlrcpp::Any visitSignedNumber(CpasParser::SignedNumberContext *ctx) override;
        antlrcpp::Any visitIntegerConst(CpasParser::IntegerConstContext *ctx) override;
        antlrcpp::Any visitAddition_subtractionExpr(CpasParser::Addition_subtractionExprContext *ctx) override;
        antlrcpp::Any visitMultiply_divideExpr(CpasParser::Multiply_divideExprContext *ctx) override;
        antlrcpp::Any visitCharConst(CpasParser::CharConstContext *ctx) override;
        antlrcpp::Any visitPrint_stmt(CpasParser::Print_stmtContext *ctx) override;
        antlrcpp::Any visitFloatConst(CpasParser::FloatConstContext *ctx) override;
    	antlrcpp::Any visitRelationOpExpr(CpasParser::RelationOpExprContext *ctx) override;
    	antlrcpp::Any visitFunction_defn(CpasParser::Function_defnContext *ctx) override;
    	antlrcpp::Any visitFunction_call(CpasParser::Function_callContext *ctx) override;
    	antlrcpp::Any visitReturn_stmt(CpasParser::Return_stmtContext *ctx) override;
    	antlrcpp::Any visitBlock(CpasParser::BlockContext *ctx) override;
        antlrcpp::Any visitStmt(CpasParser::StmtContext *ctx) override;
        antlrcpp::Any visitDeclaration_stmt(CpasParser::Declaration_stmtContext *ctx) override;
        antlrcpp::Any visitAssignment_stmt(CpasParser::Assignment_stmtContext *ctx) override;
};
#endif /* PASS2VISITOR_H_ */
